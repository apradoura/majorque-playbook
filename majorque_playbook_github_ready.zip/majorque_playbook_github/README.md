# Majorque Playbook

Assistant de voyage familial installable en PWA.

## Publication GitHub Pages

1. Déposer tous les fichiers de ce dossier à la racine du dépôt.
2. Ouvrir **Settings > Pages**.
3. Choisir **Deploy from a branch**.
4. Sélectionner **main** et **/(root)**, puis **Save**.
5. L'application sera accessible à :
   `https://apradoura.github.io/majorque-playbook/`

## Installation sur iPhone

1. Ouvrir l'URL dans Safari.
2. Toucher **Partager**.
3. Choisir **Ajouter à l'écran d'accueil**.
4. Ouvrir ensuite l'icône **Majorque**.

Code de l'espace Papa : `1011`.
